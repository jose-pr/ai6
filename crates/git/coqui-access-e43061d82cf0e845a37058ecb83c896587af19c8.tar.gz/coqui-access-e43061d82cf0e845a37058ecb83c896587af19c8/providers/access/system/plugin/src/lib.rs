//! `coqui-access-system` as a library a host loads: the Guatiao entry point for its provider,
//! and nothing else.

coqui_access::guatiao::providers!(coqui_access_system::SystemAccounts);
