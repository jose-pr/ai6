// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

/// guatiao-remote-server on loopback over WebSocket or WebTransport,
/// serving `derived_greeter` for the greeter kinds: started by the VM suite
/// directly, and by a browser suite through a hybrid isolate.
///
/// The server is `GUATIAO_REMOTE_SERVER`, else the workspace's debug
/// build; the library is the one beside it. Missing, the suite fails
/// naming the build that makes them.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:stream_channel/stream_channel.dart';

import 'remote_key.dart';

Directory _repo() {
  var dir = Directory.current.absolute;
  while (!File('${dir.path}/Cargo.toml').existsSync() ||
      !Directory('${dir.path}/crates').existsSync()) {
    final up = dir.parent;
    if (up.path == dir.path) {
      throw StateError('no guatiao checkout above ${Directory.current.path}');
    }
    dir = up;
  }
  return dir;
}

String _library(String dir) {
  if (Platform.isWindows) return '$dir/derived_greeter.dll';
  if (Platform.isMacOS) return '$dir/libderived_greeter.dylib';
  return '$dir/libderived_greeter.so';
}

/// A running server: [url] to connect to, [stop] to end it, over TLS the
/// [fingerprint] it presents, and over WebTransport the [hashes] a page
/// pins.
final class RemoteServer {
  RemoteServer._(
    this.url,
    this.fingerprint,
    this.hashes,
    this._process,
    this._dir,
  );

  final Uri url;
  final String? fingerprint;
  final List<String> hashes;
  final Process _process;
  final Directory _dir;
  Future<void>? _stopping;

  /// Ends the server and removes its key. Idempotent.
  Future<void> stop() => _stopping ??= () async {
    _process.kill();
    await _process.exitCode;
    _dir.deleteSync(recursive: true);
  }();
}

/// What [startRemoteServer] listens with for server TLS: `wss://`, an
/// identity it makes, the suite's key.
const List<String> serverTlsArguments = [
  '--listen',
  'wss://127.0.0.1:0',
  '--security',
  'server-tls',
  '--identity',
  '{dir}/server.pem',
  '--key-file',
  '{key}',
];

/// What [startRemoteServer] listens with for WebTransport at [security]
/// (`server-tls`, `none` or `mutual-tls`): `https://`, certificates it
/// makes itself, which a page pins by hash.
List<String> webTransportArguments(String security) => [
  '--listen',
  'https://127.0.0.1:0',
  '--security',
  security,
  // A client pinned, rotating certificates the page takes: Chrome then
  // refuses the link for want of a client certificate alone.
  if (security == 'mutual-tls') ...['--pin', 'sha256:${'cd' * 32}'],
  if (security == 'none') ...['--range', '127.0.0.1'],
  if (security != 'mutual-tls') ...['--key-file', '{key}'],
];

/// Starts the server and waits for the address it serves: by default
/// `ws://` with no security and the suite's key; [listen] replaces those
/// arguments, `{key}` in one standing for the key file's path and `{dir}`
/// for a directory of the server's own.
Future<RemoteServer> startRemoteServer({List<String>? listen}) async {
  final repo = _repo();
  final named = Platform.environment['GUATIAO_REMOTE_SERVER'];
  final exe = Platform.isWindows ? '.exe' : '';
  final server = File(
    named != null && named.isNotEmpty
        ? named
        : '${repo.path}/target/debug/guatiao-remote-server$exe',
  );
  final library = File(_library(server.parent.path));
  if (!server.existsSync() || !library.existsSync()) {
    throw StateError(
      'no ${server.path} beside ${library.path}: build them with '
      '`cargo build -p guatiao-source-remote -p derived_greeter '
      '--features guatiao-source-remote/ws,guatiao-source-remote/tls,'
      'guatiao-source-remote/webtransport` '
      '(or name the server in GUATIAO_REMOTE_SERVER)',
    );
  }
  final dir = Directory.systemTemp.createTempSync('guatiao-remote-');
  final keyFile = File('${dir.path}/link.key')..writeAsStringSync(remoteKey);
  final process = await Process.start(server.path, [
    ...?listen?.map(
      (a) => a.replaceAll('{key}', keyFile.path).replaceAll('{dir}', dir.path),
    ),
    if (listen == null) ...[
      '--listen',
      'ws://127.0.0.1:0',
      '--security',
      'none',
      '--range',
      '127.0.0.1',
      '--key-file',
      keyFile.path,
    ],
    '--kinds',
    '${repo.path}/examples/greeter_kind/include/greeter_kind.kinds.json',
    '--load',
    library.path,
  ]);
  return _serving(process, dir);
}

/// Starts the WebTransport server that sends every datagram back
/// (guatiao-source-remote's `datagram_echo` example, beside the server),
/// at no security with the suite's key.
Future<RemoteServer> startDatagramEcho() async {
  final repo = _repo();
  final named = Platform.environment['GUATIAO_REMOTE_SERVER'];
  final exe = Platform.isWindows ? '.exe' : '';
  final server = File(
    named != null && named.isNotEmpty
        ? named
        : '${repo.path}/target/debug/guatiao-remote-server$exe',
  );
  final echo = File('${server.parent.path}/examples/datagram_echo$exe');
  if (!echo.existsSync()) {
    throw StateError(
      'no ${echo.path}: build it with `cargo build -p guatiao-source-remote '
      '--features webtransport --example datagram_echo`',
    );
  }
  final dir = Directory.systemTemp.createTempSync('guatiao-remote-');
  return _serving(await Process.start(echo.path, [remoteKey]), dir);
}

/// Waits for the address [process] says it serves (and over WebTransport
/// the hashes it says next); a server that exits first, or says nothing
/// in time, fails it.
Future<RemoteServer> _serving(Process process, Directory dir) async {
  unawaited(process.stdout.drain<void>());
  final serving = Completer<(Uri, String?, List<String>)>();
  final said = <String>[];
  Uri? url;
  String? fingerprint;
  process.stderr.transform(utf8.decoder).transform(const LineSplitter()).listen(
    (line) {
      said.add(line);
      final m = RegExp(r'serving ((?:wss?|https)://[^\s/]+)').firstMatch(line);
      if (m != null) {
        url = Uri.parse('${m[1]}/');
        fingerprint = RegExp(r' as (sha256:[0-9a-f]+)').firstMatch(line)?[1];
      }
      final hashes = RegExp(r'certificate hashes (.+)$').firstMatch(line);
      final at = url;
      if (at != null &&
          !serving.isCompleted &&
          (hashes != null || at.scheme != 'https')) {
        serving.complete((at, fingerprint, hashes?[1]!.split(' ') ?? []));
      }
    },
  );
  unawaited(
    process.exitCode.then((code) {
      if (!serving.isCompleted) {
        serving.completeError(
          StateError('the server exited ($code): ${said.join('\n')}'),
        );
      }
    }),
  );
  try {
    final (url, fingerprint, hashes) = await serving.future.timeout(
      const Duration(seconds: 30),
    );
    return RemoteServer._(url, fingerprint, hashes, process, dir);
  } catch (_) {
    process.kill();
    dir.deleteSync(recursive: true);
    rethrow;
  }
}

/// For a browser suite: starts the server (at server TLS over `wss://`
/// when [message] is `server-tls`, over WebTransport at a security when it
/// is `https <security>`, the datagram echo when it is `datagram-echo`)
/// and sends its URL and the hashes a page pins,
/// space-separated; `stop` ends it and is answered `stopped`, since the
/// isolate may be killed as soon as the suite is done with it.
Future<void> hybridMain(StreamChannel<Object?> channel, Object? message) async {
  try {
    final server = message == 'datagram-echo'
        ? await startDatagramEcho()
        : await startRemoteServer(
            listen: switch (message) {
              'server-tls' => serverTlsArguments,
              String m when m.startsWith('https ') => webTransportArguments(
                m.substring(6),
              ),
              _ => null,
            },
          );
    channel.sink.add([server.url.toString(), ...server.hashes].join(' '));
    channel.stream.listen((message) async {
      if (message == 'stop') {
        await server.stop();
        channel.sink.add('stopped');
      }
    }, onDone: server.stop);
  } catch (e) {
    channel.sink.add('error: $e');
  }
}
