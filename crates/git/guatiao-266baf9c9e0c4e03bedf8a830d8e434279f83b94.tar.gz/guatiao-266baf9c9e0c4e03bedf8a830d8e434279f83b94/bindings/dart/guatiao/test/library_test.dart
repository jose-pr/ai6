// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

/// `library.dart` against a real build: every library resolves, the
/// default allocator fills once, and a name nothing answers to reports
/// where it looked.
@TestOn('vm')
library;

import 'dart:ffi';
import 'dart:io';

import 'package:guatiao/guatiao.dart';
import 'package:guatiao/src/library.dart' as native;
import 'package:test/test.dart';

import 'support.dart';

/// The core's own library, which carries no other surface.
String _coreFile() =>
    [libraryDir(), dllFilename('guatiao')].join(Platform.pathSeparator);

void main() {
  setUpAll(libraryDir);

  test('a pointer width the layout is not written for is refused', () {
    expect(() => native.requireWordSize(2), throwsUnsupportedError);
    expect(() => native.requireWordSize(16), throwsUnsupportedError);
    native.requireWordSize(4);
    native.requireWordSize(8);
    expect(sizeOf<IntPtr>(), anyOf(4, 8));
  });

  test('the core library loads and fills its allocator once', () {
    final lib = native.core();
    final first = lib.alloc;
    expect(identical(first, lib.alloc), isTrue);
    // A uint32_t, then four pointers aligned to their width.
    expect(first.ref.struct_size, 5 * sizeOf<IntPtr>());
    expect(first.ref.alloc, isNot(equals(nullptr)));
    expect(first.ref.free, isNot(equals(nullptr)));
  });

  test('an --all-features build exports the load surface', () {
    final lib = native.core();
    for (final name in [
      'guatiao_registry_new',
      'guatiao_registry_retire',
      'guatiao_registry_unload',
      'guatiao_registry_unload_unchecked',
      'guatiao_registry_collect',
    ]) {
      expect(lib.provides(name), isTrue, reason: name);
    }
  });

  test('another surface opens its own library, with every format built', () {
    for (final name in [
      'guatiao_json_parse',
      'guatiao_toml_parse',
      'guatiao_yaml_parse',
    ]) {
      expect(
        native.openSurface('guatiao_serde').provides(name),
        isTrue,
        reason: name,
      );
    }
    expect(
      native.openSurface('guatiao_intake').provides('guatiao_intake_check'),
      isTrue,
    );
    expect(
      native.openSurface('guatiao_serde').path,
      namedLibraryFile() ?? endsWith(dllFilename('guatiao_serde')),
    );
  });

  test('a WebAssembly module is for the web', () async {
    final refusal = isA<Unsupported>().having(
      (e) => e.message,
      'message',
      contains('is for the web'),
    );
    await expectLater(loadModule(Uri.parse('guatiao.wasm')), throwsA(refusal));
    await expectLater(loadModuleBytes(const [0]), throwsA(refusal));
  });

  test('a missing symbol names the library and the feature', () {
    expect(
      () => native.core().require('guatiao_not_a_symbol', feature: 'load'),
      throwsA(
        isA<MissingSymbol>()
            .having((e) => e.name, 'name', 'guatiao_not_a_symbol')
            .having((e) => e.feature, 'feature', 'load'),
      ),
    );
  });

  test('an unknown base name reports both places it looked', () {
    expect(
      // A probe no library exports: a file GUATIAO_LIBRARY names is then
      // passed over rather than taken as it is.
      () => native.NativeLib.open(
        'not_a_real_guatiao_library',
        probe: 'guatiao_not_a_symbol',
      ),
      throwsA(
        isA<LibraryNotFound>().having(
          (e) => e.toString(),
          'message',
          allOf(
            contains('GUATIAO_LIBRARY'),
            contains('libraryDirectory'),
            contains('search path'),
            contains(dllFilename('not_a_real_guatiao_library')),
          ),
        ),
      ),
    );
  });

  group('a library registered by hand', () {
    tearDown(native.forgetLibraries);

    test('answers for every surface it carries, and no other', () {
      final path = _coreFile();
      useLibrary(DynamicLibrary.open(path), path: path);

      // The core surface is there; the serde one is a separate library,
      // so it was not claimed on this library's behalf.
      expect(native.core().path, path);
      expect(() => native.openSurface('guatiao_serde').path, returnsNormally);
      expect(native.openSurface('guatiao_serde').path, isNot(path));
    });

    test('takes the caller word when the surfaces are named', () {
      final path = _coreFile();
      useLibrary(
        DynamicLibrary.open(path),
        path: path,
        forSurfaces: const ['guatiao_intake'],
      );
      expect(native.openSurface('guatiao_intake').path, path);
    });

    test('refuses a name that is not a surface', () {
      final path = _coreFile();
      expect(
        () => useLibrary(
          DynamicLibrary.open(path),
          forSurfaces: const ['guatiao_nonesuch'],
        ),
        throwsArgumentError,
      );
    });

    test('is forgotten on request', () {
      final path = _coreFile();
      useLibrary(DynamicLibrary.open(path), path: path);
      expect(native.core().path, path);
      native.forgetLibraries();
      expect(native.core().path, isNot('<registered>'));
    });
  });
}
