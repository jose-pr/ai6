// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

/// A link over WebSocket to guatiao-remote-server on loopback, serving
/// `derived_greeter`: on the VM, and in a browser as a page would. Then
/// the link against a peer the suite plays itself, for what a well-behaved
/// server never does.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:fake_async/fake_async.dart';
import 'package:guatiao/guatiao.dart'
    show BadValue, Busy, Gone, NotFound, Unsupported, WrongKind;
import 'package:guatiao/remote.dart';
import 'package:guatiao/src/remote/args.dart';
import 'package:guatiao/src/remote/codec.dart';
import 'package:guatiao/src/remote/proof.dart' as proof;
import 'package:test/test.dart';

import 'remote_key.dart';
import 'support.dart';

late final Uri _url;
Future<void> Function()? _stop;

Future<RemoteLink> _connect({String key = remoteKey}) => RemoteLink.connect(
  _url,
  security: RemoteSecurity.none,
  key: utf8.encode(key),
);

/// A link with `derived_greeter` opened, and its `Hello` provider.
Future<(RemoteLink, RemoteProvider)> _hello() async {
  final link = await _connect();
  final catalog = await link.list();
  final library = catalog.libraries.singleWhere(
    (l) => l.id == 'derived_greeter',
  );
  await link.open(library);
  final hello = library.providers.singleWhere(
    (p) => p.id == 'derived_greeter_hello',
  );
  return (link, hello);
}

/// Both ends of a link the suite plays the server of.
final class _Pipe implements RemoteChannel {
  final _toPeer = StreamController<Uint8List>();
  final _fromPeer = StreamController<Uint8List>();
  late final StreamIterator<Uint8List> sent = StreamIterator(_toPeer.stream);

  @override
  Stream<Uint8List> get messages => _fromPeer.stream;

  @override
  void send(Uint8List body) => _toPeer.add(body);

  @override
  RemoteDatagrams? get datagrams => null;

  @override
  Future<void> close() async {
    if (!_fromPeer.isClosed) await _fromPeer.close();
  }

  /// The next frame the link sent.
  Future<Frame> next() async {
    expect(await sent.moveNext(), isTrue, reason: 'the link sent nothing');
    return Frame.decode(sent.current);
  }

  void reply(Frame frame) => _fromPeer.add(frame.encode());
}

/// Kinds of the suite's own: `maker` hands the peer an `echo` this side
/// serves, or two listeners, or lends it an `echo` and is answered one;
/// an `echo` takes listeners handed over.
const List<Object?> _ownKinds = [
  {
    'name': 'maker',
    'object': false,
    'slots': [
      {
        'name': 'make',
        'args': [
          {'name': 'e', 'type': 'object', 'kind': 'echo', 'pass': 'taken'},
        ],
      },
      {
        'name': 'pair',
        'args': [
          {'name': 'a', 'type': 'object', 'kind': 'listener', 'pass': 'taken'},
          {'name': 'b', 'type': 'object', 'kind': 'listener', 'pass': 'taken'},
        ],
      },
      {
        'name': 'wrap',
        'args': [
          {'name': 'e', 'type': 'object', 'kind': 'echo', 'pass': 'lent'},
        ],
        'answer': {'type': 'object', 'kind': 'echo'},
      },
    ],
  },
  {
    'name': 'echo',
    'object': true,
    'slots': [
      {
        'name': 'big',
        'answer': {'type': 'text'},
      },
      {
        'name': 'fill',
        'args': [
          {'name': 'dst', 'type': 'bytes_mut'},
        ],
        'answer': {'type': 'i64'},
      },
      {
        'name': 'take',
        'args': [
          {'name': 'l', 'type': 'object', 'kind': 'listener', 'pass': 'taken'},
        ],
      },
      {
        'name': 'take2',
        'args': [
          {'name': 'a', 'type': 'object', 'kind': 'listener', 'pass': 'taken'},
          {'name': 'b', 'type': 'object', 'kind': 'listener', 'pass': 'taken'},
        ],
      },
    ],
  },
];

/// The example greeter kinds, as their description.
Future<Map<String, Object?>> _greeterKinds() async =>
    jsonDecode(
          await readRepoText([
            'examples',
            'greeter_kind',
            'include',
            'greeter_kind.kinds.json',
          ]),
        )
        as Map<String, Object?>;

/// A link at the local level over a [_Pipe], its catalog listed: one
/// provider whose greeter table fills only `greet`, `start` and
/// `greet_into`, and whose `maker` table fills every slot. [welcome] is what
/// the peer offers, [maxCalls] how many of its calls this side runs;
/// [kinds] the greeter kinds when read already.
Future<(RemoteLink, _Pipe, RemoteProvider)> _scripted({
  Duration? timeout,
  Map<String, Object?> welcome = const {},
  int maxCalls = 64,
  Map<String, Object?>? kinds,
}) async {
  kinds ??= await _greeterKinds();
  final pipe = _Pipe();
  final linking = RemoteLink.over(
    pipe,
    trust: RemoteTrust.local,
    timeout: timeout,
    maxCalls: maxCalls,
  );
  expect(await pipe.next(), isA<Hello>());
  pipe.reply(Welcome(Uint8List(16), Uint8List(0), welcome));
  final link = await linking;
  final listing = link.list();
  final ask = await pipe.next() as ListCatalog;
  final catalog = {
    'kinds': [...kinds['kinds'] as List, ..._ownKinds],
    'libraries': [
      {
        'id': 'scripted',
        'version': '1',
        'stamp': 's1',
        'providers': [
          {
            'id': 'p',
            'name': 'P',
            'tables': [
              {
                'kind': 'greeter',
                'table': 1,
                'slots': ['greet', 'start', 'greet_into'],
              },
              {
                'kind': 'maker',
                'table': 2,
                'slots': ['make', 'pair', 'wrap'],
              },
            ],
          },
        ],
      },
    ],
  };
  pipe.reply(Reply(ask.call, 0, (FrameWriter()..value(catalog)).done()));
  return (link, pipe, (await listing).providers.single);
}

/// What a future came to, recorded as it settles so an error is never
/// left unhandled while the test moves time.
final class _Outcome<T> {
  _Outcome(Future<T> future) {
    future.then(
      (v) {
        value = v;
        done = true;
      },
      onError: (Object e) {
        error = e;
        done = true;
      },
    );
  }

  bool done = false;
  T? value;
  Object? error;
}

/// [future]'s value once every microtask under [time] has run; its error
/// thrown, and a failure when it is still waiting.
T _settled<T>(FakeAsync time, Future<T> future) {
  final outcome = _Outcome(future);
  time.flushMicrotasks();
  if (!outcome.done) fail('still waiting with no time passing');
  if (outcome.error case final e?) throw e;
  return outcome.value as T;
}

/// Hands the peer [echo] through `maker.make`; the id the peer holds it by.
Future<int> _handEcho(_Pipe pipe, RemoteProvider provider, Served echo) async {
  final maker = provider.table('maker')!;
  final making = maker.call('make', [echo]);
  final make = await pipe.next() as Call;
  final ref =
      decodeArgs(maker.kind.slot('make'), make.args).single! as ObjectRef;
  pipe.reply(Reply(make.call, 0, Uint8List(0)));
  await making;
  return ref.id;
}

/// The peer's `echo.take` (slot 2) or `echo.take2` (slot 3) on [echo],
/// handing [refs] over.
Call _take(int call, int parent, int echo, List<ObjectRef> refs) {
  final slot = RemoteKind.fromDescription(_ownKinds[1]).slots[refs.length + 1];
  return Call(
    call,
    parent,
    Target.object(echo),
    slot.index,
    encodeArgs(slot, refs),
  );
}

void main() {
  setUpAll(() async {
    final (url, stop) = await remoteServer();
    _url = url;
    _stop = stop;
  });

  tearDownAll(() => _stop?.call());

  test('the catalog lists the greeter kinds and their providers', () async {
    final link = await _connect();
    final catalog = await link.list();
    expect(
      catalog.kinds.keys,
      containsAll(['greeter', 'listener', 'conversation', 'counter', 'wide']),
    );
    expect(catalog.kinds['listener']!.object, isTrue);
    final library = catalog.libraries.singleWhere(
      (l) => l.id == 'derived_greeter',
    );
    expect(library.stamp, isNotEmpty);
    expect(
      library.providers.map((p) => p.id),
      contains('derived_greeter_hello'),
    );
    expect(await link.ping(), isA<Duration>());
    await link.close();
  });

  test('a page greets through the greeter kind', () async {
    final (link, hello) = await _hello();
    final greeter = hello.table('greeter')!;
    expect(await greeter.call('greet', ['web']), {'greeting': 'hello, web'});
    await expectLater(
      greeter.call('greet', ['']),
      throwsA(
        isA<BadValue>().having((e) => e.message, 'message', 'nobody to greet'),
      ),
    );
    expect(
      await greeter.call('greet_from', [
        {'name': 'map'},
      ]),
      {'greeting': 'hello, map'},
    );
    final counter = hello.table('counter')!;
    final first = await counter.call('count') as int;
    expect(await counter.call('count'), first + 1);
    await link.close();
  });

  test('a lent map comes back written in place', () async {
    final (link, hello) = await _hello();
    final config = <String, Object?>{};
    expect(await hello.table('greeter')!.call('check', [config]), isTrue);
    expect(config, {'name': 'world', 'greeting': 'hello, world'});
    await link.close();
  });

  test('a lent listener is called during the call, and only then', () async {
    final (link, hello) = await _hello();
    final heard = <String>[];
    final listener = Served('listener', {
      'heard': (args) => heard.add(args[0]! as String),
    });
    await hello.table('greeter')!.call('greet_into', ['lent', listener]);
    expect(heard, ['hello, lent']);
    expect(link.objectsHeld, 0, reason: 'lent for the call alone');
    await link.close();
  });

  test(
    'a handed listener is called back during calls on what it was handed to',
    () async {
      final (link, hello) = await _hello();
      final heard = <String>[];
      final listener = Served('listener', {
        'heard': (args) => heard.add(args[0]! as String),
      });
      final chat =
          await hello.table('greeter')!.call('start', [listener])
              as RemoteObject;
      expect(chat.kind.name, 'conversation');
      await chat.call('say', ['hi']);
      expect(heard, ['hi'], reason: 'heard while `say` was open');
      await chat.call('say', ['there']);
      expect(heard, ['hi', 'there']);
      expect(await chat.call('turns'), 2);
      final buffer = Uint8List(64);
      final n = await chat.call('read', [buffer]) as int;
      expect(utf8.decode(buffer.sublist(0, n)), 'hi\nthere');
      expect(link.objectsHeld, 1, reason: 'the listener, handed over');
      chat.release();
      await expectLater(chat.call('turns'), throwsA(isA<Gone>()));
      // The conversation dropped, it lets the listener go.
      for (var i = 0; i < 100 && link.objectsHeld > 0; i++) {
        await link.ping();
      }
      expect(link.objectsHeld, 0);
      await link.close();
    },
  );

  test('64-bit integers cross at their limits', () async {
    final (link, hello) = await _hello();
    final wide = hello.table('wide')!;
    final min = BigInt.parse('-9223372036854775808');
    final max = BigInt.parse('18446744073709551615');
    final i64 = await wide.call('echo_i64', [min]);
    expect(i64 is BigInt ? i64 : BigInt.from(i64! as int), min);
    expect(await wide.call('echo_u64', [max]), max);
    expect(await wide.call('echo_i64', [-5]), -5);
    await expectLater(
      wide.call('echo_u64', [-1]),
      throwsArgumentError,
      reason: 'below u64',
    );
    await link.close();
  });

  test('a wrong key is refused before the link is up', () async {
    await expectLater(
      _connect(key: 'not the key'),
      throwsA(
        isA<BadValue>().having(
          (e) => e.message,
          'message',
          contains("does not hold this link's key"),
        ),
      ),
    );
  });

  test('a closed link answers Gone', () async {
    final (link, hello) = await _hello();
    await link.close();
    expect(link.alive, isFalse);
    expect(await link.done, contains('closed'));
    await expectLater(
      hello.table('greeter')!.call('greet', ['late']),
      throwsA(isA<Gone>()),
    );
  });

  group('security', () {
    test(
      'server TLS over wss: the server by its certificate, this side by the key',
      () async {
        final (url, fingerprint, stop) = await serverTlsServer();
        try {
          final link = await RemoteLink.connect(
            url,
            security: RemoteSecurity.serverTls,
            key: utf8.encode(remoteKey),
            tls: fingerprint == null ? null : RemoteTls(pins: [fingerprint]),
          );
          expect(link.trust, RemoteTrust.serverTls);
          final catalog = await link.list();
          final library = catalog.libraries.singleWhere(
            (l) => l.id == 'derived_greeter',
          );
          await link.open(library);
          final greeter = library.providers.first.table('greeter')!;
          expect(await greeter.call('greet', ['tls']), {
            'greeting': 'hello, tls',
          });
          await link.close();
          await expectLater(
            RemoteLink.connect(
              url,
              security: RemoteSecurity.serverTls,
              key: utf8.encode('not the key'),
              tls: fingerprint == null ? null : RemoteTls(pins: [fingerprint]),
            ),
            throwsA(isA<BadValue>()),
          );
        } finally {
          await stop();
        }
      },
    );

    test('a URL must agree with the security asked', () async {
      final key = utf8.encode(remoteKey);
      await expectLater(
        RemoteLink.connect(Uri.parse('ws://127.0.0.1:9/'), key: key),
        throwsA(
          isA<ArgumentError>().having(
            (e) => e.message,
            'message',
            contains('security: RemoteSecurity.none'),
          ),
        ),
        reason: 'mutual TLS unless told, and ws:// carries no TLS',
      );
      await expectLater(
        RemoteLink.connect(
          Uri.parse('wss://127.0.0.1:9/'),
          security: RemoteSecurity.none,
          key: key,
        ),
        throwsA(isA<ArgumentError>()),
      );
      await expectLater(
        RemoteLink.connect(
          Uri.parse('wss://127.0.0.1:9/'),
          security: RemoteSecurity.serverTls,
        ),
        throwsA(
          isA<ArgumentError>().having(
            (e) => e.message,
            'message',
            contains('a key or a token'),
          ),
        ),
      );
    });

    test('server TLS proves the key when the WELCOME asks for it', () async {
      final key = utf8.encode('k');
      final pipe = _Pipe();
      final linking = RemoteLink.over(
        pipe,
        trust: RemoteTrust.serverTls,
        key: key,
        timeout: null,
      );
      final hello = await pipe.next() as Hello;
      expect(hello.trust, 3);
      final server = Uint8List.fromList(List.filled(16, 7));
      pipe.reply(
        Welcome(
          server,
          proof.proofOf(key, proof.serverLabel, hello.nonce, server),
          const {},
        ),
      );
      final answered = await pipe.next() as Proof;
      expect(
        answered.proof,
        proof.proofOf(key, proof.clientLabel, hello.nonce, server),
      );
      final link = await linking;
      expect(link.trust, RemoteTrust.serverTls);
      await link.close();
    });

    test('server TLS with a token sends no proof when none is asked', () async {
      final pipe = _Pipe();
      final linking = RemoteLink.over(
        pipe,
        trust: RemoteTrust.serverTls,
        token: 't0k',
        timeout: null,
      );
      final hello = await pipe.next() as Hello;
      expect((hello.options as Map)['token'], 't0k');
      pipe.reply(Welcome(Uint8List(16), Uint8List(0), const {}));
      final link = await linking;
      expect(link.alive, isTrue);
      await link.close();
    });

    test('a server asking for a key this client lacks is refused', () async {
      final pipe = _Pipe();
      final linking = RemoteLink.over(
        pipe,
        trust: RemoteTrust.serverTls,
        token: 't0k',
      );
      final hello = await pipe.next() as Hello;
      final server = Uint8List(16);
      pipe.reply(
        Welcome(
          server,
          proof.proofOf(
            utf8.encode('k'),
            proof.serverLabel,
            hello.nonce,
            server,
          ),
          const {},
        ),
      );
      await expectLater(
        linking,
        throwsA(
          isA<BadValue>().having(
            (e) => e.message,
            'message',
            contains('has none'),
          ),
        ),
      );
    });
  });

  group('against a scripted peer', () {
    test(
      'a slot the far table leaves out is Unsupported, and nothing is sent',
      () async {
        final (link, pipe, provider) = await _scripted();
        final table = provider.table('greeter')!;
        expect(table.has('shout'), isFalse);
        await expectLater(
          table.call('shout', ['x']),
          throwsA(isA<Unsupported>()),
        );
        final ping = link.ping();
        final frame = await pipe.next();
        expect(frame, isA<Ping>(), reason: 'the refused call sent nothing');
        pipe.reply(Pong((frame as Ping).n));
        await ping;
        await link.close();
      },
    );

    test(
      'a call past its timeout is cancelled, and an object its late answer carries is released',
      () async {
        final (link, pipe, provider) = await _scripted(
          timeout: const Duration(milliseconds: 200),
        );
        final table = provider.table('greeter')!;
        final listener = Served('listener', {'heard': (_) => null});
        final starting = table.call('start', [listener]);
        final call = await pipe.next() as Call;
        await expectLater(starting, throwsA(isA<Gone>()));
        final cancel = await pipe.next() as Cancel;
        expect(cancel.call, call.call);
        expect(
          link.objectsHeld,
          1,
          reason: 'the listener went out: the peer has it',
        );
        // The late answer: a conversation of the peer's, nobody to take it.
        final slot = table.kind.slot('start');
        pipe.reply(
          Reply(call.call, 0, encodeAnswer(slot, const ObjectRef(5), [null])),
        );
        final release = await pipe.next() as Release;
        expect(release.object, 5);

        // Another, whose late answer names this side's own object.
        final again = table.call('start', [listener]);
        final second = await pipe.next() as Call;
        await expectLater(again, throwsA(isA<Gone>()));
        expect(await pipe.next(), isA<Cancel>());
        expect(link.objectsHeld, 2);
        final mine = decodeArgs(slot, second.args).single! as ObjectRef;
        pipe.reply(
          Reply(
            second.call,
            0,
            encodeAnswer(slot, ObjectRef(mine.id, receivers: true), [null]),
          ),
        );
        final ping = link.ping();
        final asked = await pipe.next() as Ping;
        pipe.reply(Pong(asked.n));
        await ping;
        expect(link.objectsHeld, 1, reason: 'the one answered back is dropped');
        await link.close();
      },
    );

    test('a call made after its handler returned names no parent', () async {
      final (link, pipe, provider) = await _scripted();
      final table = provider.table('greeter')!;
      final greet = table.kind.slot('greet');
      final later = Completer<Future<Object?>>();
      final listener = Served('listener', {
        'heard': (args) async {
          await table.call('greet', ['inside']);
          Timer(Duration.zero, () {
            later.complete(table.call('greet', ['after']));
          });
          return null;
        },
      });
      final starting = table.call('start', [listener]);
      final start = await pipe.next() as Call;
      final slot = table.kind.slot('start');
      final mine = decodeArgs(slot, start.args).single! as ObjectRef;
      pipe.reply(
        Reply(start.call, 0, encodeAnswer(slot, const ObjectRef(5), [null])),
      );
      await starting;
      // The peer tells the listener something, during no call of ours.
      pipe.reply(
        Call(
          40,
          0,
          Target.object(mine.id),
          0,
          (FrameWriter()..text('x')).done(),
        ),
      );
      final inside = await pipe.next() as Call;
      expect(inside.parent, 40, reason: 'made while `heard` runs');
      pipe.reply(Reply(inside.call, 0, encodeAnswer(greet, {'g': 1}, [null])));
      final heard = await pipe.next() as Reply;
      expect([heard.call, heard.status], [40, 0]);
      final after = await pipe.next() as Call;
      expect(after.parent, 0, reason: '`heard` has returned');
      pipe.reply(Reply(after.call, 0, encodeAnswer(greet, {'g': 2}, [null])));
      expect(await (await later.future), {'g': 2});
      await link.close();
    });

    test("an answer over the peer's max_frame is refused, not sent", () async {
      final (link, pipe, provider) = await _scripted(
        welcome: {'max_frame': 64},
      );
      final maker = provider.table('maker')!;
      final echo = Served('echo', {
        'big': (_) => 'x' * 200,
        // Breaks the buffer the answer writes back.
        'fill': (args) {
          args[0] = null;
          return 0;
        },
      });
      final making = maker.call('make', [echo]);
      final make = await pipe.next() as Call;
      final ref =
          decodeArgs(maker.kind.slot('make'), make.args).single! as ObjectRef;
      pipe.reply(Reply(make.call, 0, Uint8List(0)));
      await making;
      pipe.reply(Call(60, 0, Target.object(ref.id), 0, Uint8List(0)));
      final refused = await pipe.next() as Reply;
      expect([refused.call, refused.status], [60, 7]);
      expect(refused.words(), contains('over the 64'));
      pipe.reply(
        Call(61, 0, Target.object(ref.id), 1, (FrameWriter()..uint(8)).done()),
      );
      final broken = await pipe.next() as Reply;
      expect([broken.call, broken.status], [61, 100], reason: 'still answered');
      expect(link.alive, isTrue);
      await link.close();
    });

    test('a handed object is taken back when a later argument fails', () async {
      final (link, _, provider) = await _scripted();
      await expectLater(
        provider.table('maker')!.call('pair', [
          Served('listener', {}),
          Served('echo', {}),
        ]),
        throwsA(isA<WrongKind>()),
      );
      expect(link.objectsHeld, 0);
      await link.close();
    });

    test('a slot the kind does not have fails the Future', () async {
      final (link, _, provider) = await _scripted();
      final calling = provider.table('greeter')!.call('nope');
      await expectLater(calling, throwsA(isA<NotFound>()));
      await link.close();
    });

    test('a malformed frame ends the link with GOODBYE', () async {
      final (link, pipe, _) = await _scripted();
      pipe._fromPeer.add(Uint8List.fromList([0x7f]));
      final bye = await pipe.next() as Goodbye;
      expect(bye.status, 7);
      expect(await link.done, contains('malformed'));
      expect(link.alive, isFalse);
    });

    test(
      'a call refused before it runs lets go of what it handed over',
      () async {
        final (link, pipe, provider) = await _scripted(maxCalls: 1);
        final never = Completer<Object?>();
        final echo = await _handEcho(
          pipe,
          provider,
          Served('echo', {'big': (_) => never.future, 'take': (_) => null}),
        );
        // Two listeners of this side's the peer holds.
        final maker = provider.table('maker')!;
        final pairing = maker.call('pair', [
          Served('listener', {}),
          Served('listener', {}),
        ]);
        final pair = await pipe.next() as Call;
        final mine = decodeArgs(
          maker.kind.slot('pair'),
          pair.args,
        ).cast<ObjectRef>();
        pipe.reply(Reply(pair.call, 0, Uint8List(0)));
        await pairing;
        expect(link.objectsHeld, 3);

        // Made during a call that has returned.
        pipe.reply(_take(70, 4, echo, [const ObjectRef(5)]));
        expect((await pipe.next() as Release).object, 5);
        expect([(await pipe.next() as Reply).call], [70]);
        // A slot the echo does not fill.
        pipe.reply(
          _take(71, 0, echo, [const ObjectRef(6), const ObjectRef(7)]),
        );
        expect((await pipe.next() as Release).object, 6);
        expect((await pipe.next() as Release).object, 7);
        final unfilled = await pipe.next() as Reply;
        expect([unfilled.call, unfilled.status], [71, 13]);
        // Past this side's max_calls: the one place runs `big`, forever.
        pipe.reply(Call(72, 0, Target.object(echo), 0, Uint8List(0)));
        pipe.reply(_take(73, 0, echo, [const ObjectRef(8)]));
        expect((await pipe.next() as Release).object, 8);
        final busy = await pipe.next() as Reply;
        expect([busy.call, busy.status], [73, 14]);
        // This side's own, given back in a refused call, is dropped.
        pipe.reply(
          _take(74, 4, echo, [ObjectRef(mine[0].id, receivers: true)]),
        );
        expect((await pipe.next() as Reply).call, 74);
        expect(link.objectsHeld, 2);
        never.complete(null);
        await link.close();
      },
    );

    test(
      'a call refused while its arguments are received lets each go',
      () async {
        final (link, pipe, provider) = await _scripted();
        final echo = await _handEcho(
          pipe,
          provider,
          Served('echo', {'take2': (_) => null}),
        );
        // The first is no object of this side's; the second is the peer's.
        pipe.reply(
          _take(80, 0, echo, [
            const ObjectRef(99, receivers: true),
            const ObjectRef(9),
          ]),
        );
        expect((await pipe.next() as Release).object, 9);
        final refused = await pipe.next() as Reply;
        expect([refused.call, refused.status], [80, 12]);
        await link.close();
      },
    );

    test('an object lent for a call cannot come back handed over', () async {
      final (link, pipe, provider) = await _scripted();
      final echo = await _handEcho(
        pipe,
        provider,
        Served('echo', {'take': (_) => null}),
      );
      final table = provider.table('greeter')!;
      final heard = <Object?>[];
      final listener = Served('listener', {
        'heard': (args) => heard.add(args[0]),
      });
      final greeting = table.call('greet_into', ['x', listener]);
      final greet = await pipe.next() as Call;
      final lent =
          decodeArgs(table.kind.slot('greet_into'), greet.args)[1]!
              as ObjectRef;
      pipe.reply(
        _take(90, greet.call, echo, [ObjectRef(lent.id, receivers: true)]),
      );
      final refused = await pipe.next() as Reply;
      expect([refused.call, refused.status], [90, 9]);
      // Still lent: the call it was lent for can call it.
      pipe.reply(
        Call(
          91,
          greet.call,
          Target.object(lent.id),
          0,
          (FrameWriter()..text('still')).done(),
        ),
      );
      final called = await pipe.next() as Reply;
      expect([called.call, called.status], [91, 0]);
      expect(heard, ['still']);
      pipe.reply(Reply(greet.call, 0, Uint8List(0)));
      await greeting;

      // Nor come back as an answer.
      final maker = provider.table('maker')!;
      final wrapSlot = maker.kind.slot('wrap');
      final wrapping = maker.call('wrap', [Served('echo', {})]);
      final wrap = await pipe.next() as Call;
      final mine = decodeArgs(wrapSlot, wrap.args).single! as ObjectRef;
      pipe.reply(
        Reply(
          wrap.call,
          0,
          encodeAnswer(wrapSlot, ObjectRef(mine.id, receivers: true), [null]),
        ),
      );
      await expectLater(wrapping, throwsA(isA<WrongKind>()));
      await link.close();
    });

    test(
      "a call waiting for a place under the peer's max_calls gives up Busy at its timeout",
      () async {
        final kinds = await _greeterKinds();
        // Time moves only when the test says, and every timer of one
        // instant runs in the order it was set: which call gives up first
        // is the clock's to say, not the machine's load.
        fakeAsync((time) {
          final (link, pipe, provider) = _settled(
            time,
            _scripted(
              timeout: const Duration(milliseconds: 300),
              welcome: {'max_calls': 1},
              kinds: kinds,
            ),
          );
          final table = provider.table('greeter')!;
          final greet = table.kind.slot('greet');
          final first = _Outcome(table.call('greet', ['a']));
          final a = _settled(time, pipe.next()) as Call;
          // Both wait for the one place the first holds.
          final second = _Outcome(table.call('greet', ['b']));
          final third = _Outcome(table.call('greet', ['c']));
          time.elapse(const Duration(milliseconds: 300));
          // The first times out and its place goes to the second, with none
          // of its time left; the third has waited its whole timeout by then.
          expect((_settled(time, pipe.next()) as Cancel).call, a.call);
          expect(first.error, isA<Gone>());
          final b = _settled(time, pipe.next()) as Call;
          expect(decodeArgs(greet, b.args), ['b']);
          expect(third.error, isA<Busy>());
          expect(
            (_settled(time, pipe.next()) as Cancel).call,
            b.call,
            reason: 'the wait counts against the call',
          );
          expect(second.error, isA<Gone>());
          final ping = _Outcome(link.ping());
          final asked = _settled(time, pipe.next());
          expect(asked, isA<Ping>(), reason: 'the third was never sent');
          pipe.reply(Pong((asked as Ping).n));
          time.flushMicrotasks();
          expect([ping.done, ping.error], [true, null]);
          _settled(time, link.close());
        });
      },
    );

    test("a call made during a call that returned is refused Gone", () async {
      final (link, pipe, _) = await _scripted();
      pipe.reply(Call(9, 4, const Target.object(1), 0, Uint8List(0)));
      final refused = await pipe.next() as Reply;
      expect(refused.call, 9);
      expect(refused.status, 12);
      await link.close();
    });

    test(
      'a call on an object this side never served is refused Gone',
      () async {
        final (link, pipe, _) = await _scripted();
        pipe.reply(Call(3, 0, const Target.object(77), 0, Uint8List(0)));
        final refused = await pipe.next() as Reply;
        expect([refused.call, refused.status], [3, 12]);
        expect(refused.words(), contains('let go'));
        await link.close();
      },
    );
  });
}
